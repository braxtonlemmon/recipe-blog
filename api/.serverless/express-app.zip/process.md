# This is the step-by-step process I followed:

<!-- set up -->
- $ express --view=ejs recipe-blog
- $ npm install

<!-- git -->
- git remote add origin git@github.com:braxtonlemmon/recipe-blog.git
- git remote add gitlab git@gitlab.com:braxtonlemmon/recipe-blog.git

- git remote set-url --add --push git@github.com:braxtonlemmon/recipe-blog.git
- git remote set-url --add --push git@gitlab.com:braxtonlemmon/recipe-blog.git

- git push -u origin master

<!-- dev environment setup -->
- $ npm i nodemon --save-dev
- in package.json "scripts"
-   "devstart": "nodemon ./bin/www"
-   "serverstart": "DEBUG=recipe-blog:* npm run devstart"
- $ npm i dotenv
- in app.js:
-   import 'dotenv/config'
-   use with process.env.SECRET_CODE

<!-- setup mongoose db -->
- new project on cloud.mongodb.com
- build a cluster
- connect to cluster (ip: 0.0.0.0/0)
- add MONGODB_URI to .env
- $ npm i mongoose
- in app.js:
-   import mongoose from 'mongoose';
-   const mongoDB = process.env.MONGODB_URI
-   mongoose.connect(mongoDB, { useNewUrlParser: true, useFindAndModify: false });
-   const db = mongoose.connection
-   db.on('error', console.error.bind(console, 'MongoDB connection error'));

<!-- models -->
- $ mkdir models && cd models && touch user.js recipe.js comment.js
- in a model file:
-   import mongoose from 'mongoose'
-   const Schema = mongoose.Schema;
-   const UserSchema = new Schema({
      property: {type: String, required: true },
      etc.
-   })
-   module.exports = mongoose.model('User', UserSchema);

<!-- babel -->
- $ npm install @babel/core @babel/node --save-dev
- package.json "start" script: 
-   "nodemon --exec babel-node ./bin/www"
- $ npm install @babel/preset-env --save-dev
- $ touch .babelrc
- add to .babelrc:
-   { "presets": [ "@babel/preset/env" ] }

<!-- Moment -->
- $ npm i moment
- import moment from 'moment';
- an example: moment(someDate).format('MMMM Do YYYY, h:mm a')

<!-- pre-deploy -->
- $ npm i compression helmet
- in app.js:
-   import helmet from 'helmet';
-   import compressio from 'compression';
-   app.use(compression());
-   app.use(helmet());

<!-- express validator -->
- $ npm i express-validator
- in controller:
-   import { body, validationResult } from 'express-validator'

<!-- passport w/ tokens-->
- $ npm i express-session passport passport-local passport-jwt jsonwebtoken
- make passport.js and put local passport strategy; require in app.js
- make auth.js route file and put login logic

<!-- bcrypt -->

<!-- Cors -->
- $ npm i cors
- in app.js:
-   import Cors from 'cors';
-   app.use(Cors());